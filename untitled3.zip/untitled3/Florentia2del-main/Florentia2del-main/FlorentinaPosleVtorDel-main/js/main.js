document.addEventListener("DOMContentLoaded", () => {
    // 1. Loader
    const loader = document.getElementById("loader");
    if (loader) {
        setTimeout(() => {
            loader.style.opacity = "0";
            setTimeout(() => loader.remove(), 400);
        }, 400);
    }

    // 2. Dark Mode
    let currentTheme = localStorage.getItem("florentiaTheme") || "light";
    if (currentTheme === "dark") {
        document.documentElement.setAttribute("data-theme", "dark");
    }

    // 3. Language
    let currentLang = localStorage.getItem("florentiaLang") || "mk";

    // Header со ажурирана навигација и преместено Хабургер копче кај акциите
    const headerContainer = document.getElementById("site-header");
    if (headerContainer) {
        headerContainer.innerHTML = `
      <header class="header">
        <div class="container header-inner">
          <a class="logo" href="index.html">Florentia<span>.</span></a>
          
          <nav class="nav">
            <a href="index.html" data-i18n="home">Почетна</a>
            <a href="about.html" data-i18n="aboutTeam">За нас & Тим</a>
            
            <div class="dropdown">
              <a href="flowers.html"><span data-i18n="products">Производи (Цвеќе)</span> ▾</a>
              <div class="dropdown-menu">
                <a href="flowers.html?type=roses" data-i18n="roses">Рози</a>
                <a href="flowers.html?type=classic" data-i18n="classic">Букети</a>
                <a href="flowers.html?type=potted" data-i18n="potted">Саксиски цвеќиња</a>
              </div>
            </div>

            <a href="weddings.html" data-i18n="weddings">Свадбени аранжмани</a>
            <a href="gifts.html">Подароци</a>

            <a href="faq.html" data-i18n="faq">FAQ</a>
            <a href="contact.html" data-i18n="contact">Контакт</a>
          </nav>
          
          <div class="header-actions">
            <!-- Хабургер копчето е тука, до копчето за тема -->
            <button class="hamburger-btn" aria-label="Отвори мени">
              <span></span>
              <span></span>
              <span></span>
            </button>

            <button id="theme-toggle" class="nav-action-btn icon-btn" title="Промени тема">
              ${currentTheme === "dark" ? "☀️" : "🌙"}
            </button>
            <button id="lang-toggle" class="nav-action-btn" title="Промени јазик">
              🌐 <span id="lang-label">${currentLang.toUpperCase()}</span>
            </button>
            <a href="checkout.html" class="nav-action-btn">
              🛒 <span data-i18n="cart">Корпа</span> (<span id="cart-count">0</span>)
            </a>
          </div>
        </div>
      </header>
    `;

        const themeToggleBtn = document.getElementById("theme-toggle");
        themeToggleBtn.addEventListener("click", () => {
            let theme = document.documentElement.getAttribute("data-theme");
            if (theme === "dark") {
                document.documentElement.setAttribute("data-theme", "light");
                localStorage.setItem("florentiaTheme", "light");
                themeToggleBtn.innerText = "🌙";
            } else {
                document.documentElement.setAttribute("data-theme", "dark");
                localStorage.setItem("florentiaTheme", "dark");
                themeToggleBtn.innerText = "☀️";
            }
        });

        const langToggleBtn = document.getElementById("lang-toggle");
        const langLabel = document.getElementById("lang-label");
        langToggleBtn.addEventListener("click", () => {
            currentLang = currentLang === "mk" ? "en" : "mk";
            localStorage.setItem("florentiaLang", currentLang);
            langLabel.innerText = currentLang.toUpperCase();
            applyTranslations(currentLang);
        });
    }

    function applyTranslations(lang) {
        if (typeof translations === "undefined") return;
        const elements = document.querySelectorAll("[data-i18n]");
        elements.forEach(el => {
            const key = el.getAttribute("data-i18n");
            if (translations[lang] && translations[lang][key]) {
                el.innerText = translations[lang][key];
            }
        });
    }

    if (currentLang === "en") applyTranslations("en");

    // Footer
    const footerContainer = document.getElementById("site-footer");
    if (footerContainer) {
        footerContainer.innerHTML = `
      <footer class="footer">
        <div class="container footer-grid">
          <div>
            <h3>Florentia<span>.</span></h3>
            <p>Flowers with a story. Создадено со љубов во Скопје.</p>
          </div>
          <div>
            <h4>Брзи линкови</h4>
            <a href="index.html">Почетна</a>
            <a href="about.html">За нас & Тим</a>
            <a href="flowers.html">Производи</a>
            <a href="weddings.html">Свадбени аранжмани</a>
            <a href="gifts.html">Подароци</a>
          </div>
          <div>
            <h4>Поддршка</h4>
            <a href="faq.html">FAQ</a>
            <a href="contact.html">Контакт</a>
          </div>
        </div>
      </footer>
    `;
    }

    // Cookie Banner
    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner && !localStorage.getItem("florentiaCookieChoice")) {
        cookieBanner.style.display = "block";
    }
    document.getElementById("cookie-accept")?.addEventListener("click", () => {
        localStorage.setItem("florentiaCookieChoice", "accepted");
        cookieBanner.style.display = "none";
    });
    document.getElementById("cookie-decline")?.addEventListener("click", () => {
        localStorage.setItem("florentiaCookieChoice", "declined");
        cookieBanner.style.display = "none";
    });

    // Toast Облаче за кошничка
    let toastEl = document.getElementById("toastNotification");
    if (!toastEl) {
        toastEl = document.createElement("div");
        toastEl.id = "toastNotification";
        toastEl.className = "toast-notification";
        toastEl.innerHTML = `<span class="icon">🌸</span> <span id="toastText">Производот е додаден во кошничка!</span>`;
        document.body.appendChild(toastEl);
    }

    function showToast(message) {
        const toastText = document.getElementById("toastText");
        if (toastText) toastText.innerText = message;
        toastEl.classList.add("show");
        setTimeout(() => { toastEl.classList.remove("show"); }, 2500);
    }

    let cart = JSON.parse(localStorage.getItem("florentiaCart")) || [];

    function saveAndUp() {
        localStorage.setItem("florentiaCart", JSON.stringify(cart));
        updateCartUI();
    }

    window.addToCart = function(id, title, priceMKD, image = "") {
        const existing = cart.find(item => item.id === id);
        if (existing) {
            existing.qty += 1;
        } else {
            cart.push({ id, title, price: priceMKD, image: image, qty: 1 });
        }
        saveAndUp();
        showToast(`Успешно додадено: ${title}`);
    };

    function updateCartUI() {
        const badge = document.getElementById("cart-count");
        if (badge) {
            let totalQty = cart.reduce((acc, item) => acc + item.qty, 0);
            badge.innerText = totalQty;
        }

        const checkoutCart = document.getElementById("checkout-cart");
        if (checkoutCart) {
            if (cart.length === 0) {
                checkoutCart.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--muted);"><p style="font-size:16px; margin-bottom:15px;">Вашата кошничка е празна.</p><a href="flowers.html" class="btn btn-dark" style="font-size:14px; padding: 10px 20px;">Разгледај производи</a></div>`;
                return;
            }

            let html = '<div class="cart-items-list">';
            let total = 0;

            cart.forEach((item, index) => {
                let itemTotal = item.price * item.qty;
                total += itemTotal;
                html += `
          <div class="cart-item-row">
            <div class="cart-item-info">
              <h4>${item.title}</h4>
              <p>${item.price} ден. од парче</p>
            </div>
            <div class="cart-item-controls">
              <button class="qty-btn" onclick="changeQty(${index}, -1)">-</button>
              <span style="font-weight: 600; min-width: 20px; text-align: center;">${item.qty}</span>
              <button class="qty-btn" onclick="changeQty(${index}, 1)">+</button>
              <button class="remove-btn" onclick="removeItem(${index})">Избриши</button>
            </div>
          </div>
        `;
            });

            html += `
        <div style="margin-top: 25px; padding-top: 15px; border-top: 2px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 18px; font-weight: 600;">Вкупно за наплата:</span>
          <strong style="font-size: 22px; color: var(--primary);">${total} ден.</strong>
        </div>
      </div>`;

            checkoutCart.innerHTML = html;
        }
    }

    window.changeQty = function(index, delta) {
        cart[index].qty += delta;
        if (cart[index].qty <= 0) cart.splice(index, 1);
        saveAndUp();
    };

    window.removeItem = function(index) {
        cart.splice(index, 1);
        saveAndUp();
        showToast("Производот е отстранет од кошничката");
    };

    updateCartUI();

    // Шоп филтри и пребарување слушатели
    const searchInput = document.getElementById('searchInput');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const sortSelect = document.getElementById('sortSelect');

    if (document.body.getAttribute('data-page') === 'shop') {
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const query = e.target.value.toLowerCase().trim();
                if (typeof window.filterShopProducts === 'function') {
                    window.filterShopProducts({ search: query });
                }
            });
        }

        filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                filterButtons.forEach(b => b.classList.remove('active'));
                e.currentTarget.classList.add('active');

                const category = e.currentTarget.getAttribute('data-filter');
                if (typeof window.filterShopProducts === 'function') {
                    window.filterShopProducts({ category: category });
                }
            });
        });

        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const sortBy = e.target.value;
                if (typeof window.filterShopProducts === 'function') {
                    window.filterShopProducts({ sort: sortBy });
                }
            });
        }
    }

    // ==============================
    // РОТИРАЧКИ ЦИТАТИ
    // ==============================
    const quotes = [
        { text: "Цвеќињата се зборовите на земјата изговорени во безмолвна убавина.", author: "— Едвин Борк" },
        { text: "Каде што цветаат цвеќиња, цвета и надежта.", author: "— Лејди Бердон" },
        { text: "Земјата се смее во цвеќиња.", author: "— Ралф Волдо Емерсон" },
        { text: "Да се сака цвеќе значи да се пронајде парче од рајот на земјата.", author: "— Florentia Студио" },
        { text: "Ако можевме јасно да го видиме чудото на еден единствен цвет, целиот наш живот би се променил.", author: "— Буда" },
        { text: "Цвеќињата се музиката на земјата, изговорена без звук од нејзините усни.", author: "— Едвин Куран" },
        { text: "Цветот што цвета во неволја е најредок и најубав од сите.", author: "— Мулан" }
    ];

    let currentQuoteIndex = 0;
    const quoteTextEl = document.getElementById("quote-text");
    const quoteAuthorEl = document.getElementById("quote-author");
    const dotsContainer = document.getElementById("quote-dots");

    if (dotsContainer) {
        quotes.forEach((_, index) => {
            const dot = document.createElement("span");
            dot.className = "q-dot";
            dot.dataset.index = index;
            dot.style.cssText = `width: 10px; height: 10px; border-radius: 50%; background: ${index === 0 ? 'var(--primary)' : 'var(--border)'}; display: inline-block; transition: var(--transition); cursor: pointer;`;

            dot.addEventListener("click", () => showQuote(index));
            dotsContainer.appendChild(dot);
        });
    }

    function showQuote(index) {
        if (!quoteTextEl || !quoteAuthorEl) return;
        quoteTextEl.style.opacity = 0;
        quoteAuthorEl.style.opacity = 0;

        setTimeout(() => {
            quoteTextEl.innerText = quotes[index].text;
            quoteAuthorEl.innerText = quotes[index].author;
            quoteTextEl.style.opacity = 1;
            quoteAuthorEl.style.opacity = 1;
        }, 300);

        document.querySelectorAll(".q-dot").forEach((dot, i) => {
            dot.style.background = i === index ? "var(--primary)" : "var(--border)";
        });
        currentQuoteIndex = index;
    }

    if (quotes.length > 0) {
        setInterval(() => {
            showQuote((currentQuoteIndex + 1) % quotes.length);
        }, 5000);
    }

    // ==============================
    // МОДАЛ ЗА ИЗБРАНИ ПРОИЗВОДИ
    // ==============================
    const modal = document.getElementById("featuredProductModal");
    const modalImage = document.getElementById("featuredModalImage");
    const modalDescription = document.getElementById("featuredModalDescription");
    const modalClose = document.getElementById("featuredModalClose");
    const productCards = document.querySelectorAll(".product-grid .product-card");

    productCards.forEach(card => {
        card.addEventListener("click", (event) => {
            if (event.target.closest("button")) return;

            const image = card.querySelector(".product-image img");
            const description = card.querySelector(".card-description");
            if (!image || !description) return;

            modalImage.src = image.src;
            modalImage.alt = image.alt;
            modalDescription.textContent = description.textContent.trim();
            modal.classList.add("active");
            document.body.style.overflow = "hidden";
        });
    });

    if (modalClose) {
        modalClose.addEventListener("click", () => {
            modal.classList.remove("active");
            document.body.style.overflow = "";
        });
    }

    if (modal) {
        modal.addEventListener("click", (event) => {
            if (event.target === modal) {
                modal.classList.remove("active");
                document.body.style.overflow = "";
            }
        });
    }

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && modal && modal.classList.contains("active")) {
            modal.classList.remove("active");
            document.body.style.overflow = "";
        }
    });

    // ==============================
    // МОБИЛНО ХАБУРГЕР МЕНИ & ПОД-МЕНИ
    // ==============================
    const hamburgerBtn = document.querySelector(".hamburger-btn");
    const navMenu = document.querySelector(".nav");

    if (hamburgerBtn && navMenu) {
        hamburgerBtn.addEventListener("click", () => {
            navMenu.classList.toggle("active");
        });

        // Автоматско затворање кога ќе се кликне било кој обичен линк
        const navLinks = navMenu.querySelectorAll("a:not(.dropdown > a)");
        navLinks.forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("active");
            });
        });
    }

    // Клик за отворање/затворање на под-менито (Производи) на мобилен
    const dropdownToggle = document.querySelector(".dropdown > a");
    if (dropdownToggle) {
        dropdownToggle.addEventListener("click", (e) => {
            if (window.innerWidth <= 992) {
                e.preventDefault();
                const parentDropdown = dropdownToggle.closest(".dropdown");
                parentDropdown.classList.toggle("open");
            }
        });
    }

    // Затвори го менито кога ќе се кликне некој под-линк од производите
    const dropdownSubLinks = document.querySelectorAll(".dropdown-menu a");
    dropdownSubLinks.forEach(subLink => {
        subLink.addEventListener("click", () => {
            if (window.innerWidth <= 992 && navMenu) {
                navMenu.classList.remove("active");
                const parentDropdown = subLink.closest(".dropdown");
                if (parentDropdown) parentDropdown.classList.remove("open");
            }
        });
    });
});

// Скрол копче на врв
const scrollBtn = document.getElementById('scrollToTopBtn');
if (scrollBtn) {
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    });

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    const giftsContainer = document.getElementById("gifts-container");

    if (giftsContainer && typeof giftsData !== "undefined") {
        let html = "";

        giftsData.forEach(gift => {
            // Генерирање на беџ доколку постои
            const badgeHtml = gift.badge
                ? `<span style="position: absolute; top: 12px; left: 12px; background: ${gift.badgeColor || 'var(--primary, #d4af37)'}; color: #fff; padding: 4px 10px; font-size: 11px; font-weight: 600; border-radius: 4px; z-index: 2;">${gift.badge}</span>`
                : '';

            html += `
                <div class="gift-card" style="position: relative; border: 1px solid var(--border); border-radius: 12px; overflow: hidden; background: var(--bg-card, #fff); padding: 15px; display: flex; flex-direction: column; justify-content: space-between;">
                    ${badgeHtml}
                    <div>
                        <img src="${gift.image}" alt="${gift.title}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 12px;">
                        <h3 style="font-size: 16px; margin-bottom: 8px;">${gift.title}</h3>
                        <p style="font-size: 13px; color: var(--muted); margin-bottom: 12px;">${gift.description}</p>
                    </div>
                    <div>
                        <div style="font-size: 18px; font-weight: 600; color: var(--primary); margin-bottom: 12px;">${gift.priceMKD.toLocaleString()} ден.</div>
                        <button onclick="addToCart(${gift.id}, '${gift.title.replace(/'/g, "\\'")}', ${gift.priceMKD}, '${gift.image}')" class="btn btn-dark" style="width: 100%; padding: 10px; cursor: pointer; border: none; border-radius: 6px; background: var(--primary); color: #fff; font-weight: 600;">Додај во корпа</button>
                    </div>
                </div>
            `;
        });

        giftsContainer.innerHTML = html;
    }
});