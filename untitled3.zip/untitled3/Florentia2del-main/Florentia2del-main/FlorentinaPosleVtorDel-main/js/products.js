const productsData = [
    {
        id: 1,    //bitno da se smeni
        title: "Роза - парче",   //glavniot naslov sto stoi na kartickata
        type: "roses",  //bitno e za filterot
        priceMKD: 200,   //ranodm cena
        image: "sliki/r1.jpg",  //pateka od folderot sliki/imageBROJ_NA_SLIKA
        description: "Нежна и елегантна роза, внимателно подготвена како мал, но впечатлив подарок. Симбол на љубов, внимание и искрени чувства, совршена за да разубавите нечиј ден или да подарите мал знак на внимание."  //opisot kaj kartickata dole
    },
    {
        id: 2,
        title: "Орхидеја (Фаленопсис) - Мултиколор",
        type: "potted",
        priceMKD: 1000,
        image: "sliki/s1.avif",
        description: "Фаленопсис орхидејата потекнува од тропските предели на Азија и е симбол на елеганција и префинетост. Со своите долготрајни и нежни цветови, внесува луксуз во секој простор."
    },
    {
        id: 3,
        title: "15 Црвени Рози",
        type: "roses",
        priceMKD: 2500,
        image: "sliki/r2.avif",
        description: "Овој впечатлив букет од 15 црвени рози ја претставува љубовта, страста и искрените чувства. Богатите црвени тонови и внимателно аранжираните цветови создаваат елегантен и романтичен изглед. Совршен избор за роденден, годишнина, прослава или едноставно за да покажете некому колку ви значи."
    },
    {
        id: 4,
        title: "Алое Вера",
        type: "potted",
        priceMKD: 330,
        image: "sliki/s2.avif",
        description: " Алое вера е сукулентно растение со потекло од Африка, познато по своите месести, зелени листови богати со гел со лековити својства. Совршен избор за модерен ентериер и љубители на минималистички стил."
    },
    {
        id: 5,
        title: "15 розеви рози",
        type: "roses",
        priceMKD: 2500,
        image: "sliki/r3.avif",
        description: "Нежен и елегантен букет од 15 розеви рози, создаден да пренесе чувства на нежност, благодарност и искрена приврзаност. Префинетите розеви нијанси му даваат свеж и романтичен изглед, што го прави идеален подарок за родендени, годишнини или за секој посебен момент."
    },
    {
        id: 22,
        title: "15 Бели Рози",
        type: "roses",
        priceMKD: 2800,
        image: "sliki/r13.avif",
        description: "Овој нежен и елегантен букет од бели рози симболизира чистота, искреност и безвременска убавина. Совршено аранжираните рози создаваат хармонична и луксузна форма, додека светлата амбалажа му дава модерен и префинет изглед. Идеален избор за свадби, свечени моменти, благодарност или кога сакате да подарите елеганција во најчиста форма."
    },
    {
    id: 6,
        title: "Јука - Дрво на животот",
        type: "potted",
        priceMKD: 2330,
        image: "sliki/s3.avif",
        description: "Јуката е издржливо декоративно растение со потекло од Централна Америка, препознатливо по своето дрвенесто стебло и остри, зелени листови. Идеална за модерни и индустриски ентериери. Симболика: Сила, стабилност, издржливост."
    },
    {
        id: 7,
        title: "Фикус Женшенг (Ficus Ginseng)",
        type: "potted",
        priceMKD: 2000,
        image: "sliki/s4.avif",
        description: "Фикус Женшенг е декоративно растение со уникатно, задебелено коренесто стебло и компактна крошна. Потекнува од Азија и често се користи како бонсаи. Симболика: Долговечност, просперитет, рамнотежа."
    },
    {
        id: 8,
        title: "Спатифилум - Женска среќа",
        type: "potted",
        priceMKD: 1330,
        image: "sliki/s6.avif",
        description: "Spathiphyllum, позната како „Женска среќа“, е тропско растение со сјајни зелени листови и елегантни бели цветови. Одлично го прочистува воздухот и внесува свежина во секој простор. Симболика: Мир, хармонија, љубов и благосостојба."
    },
    {
        id: 9,
        title: "Гузманија",
        type: "potted",
        priceMKD: 630,
        image: "sliki/s5.avif",
        description: "Гузманија е впечатливо тропско растение со декоративна розета од зелени листови и интензивен црвен цветен клас во центарот. Потекнува од Јужна и Централна Америка и внесува егзотичен акцент и боја во секој ентериер. Симболика: Радост, страст, позитивна енергија."
    },
    {
        id: 10,
        title: "Фикус Бенцамин",
        type: "potted",
        priceMKD: 3630,
        image: "sliki/s7.avif",
        description: "Ficus Benjamina е грациозно растение со нежни, спуштени гранки и богата крошна од мали, сјајни листови. Потекнува од Азија и Австралија и претставува класично внатрешно дрво кое внесува леснотија и природна елеганција во секој ентериер. Симболика: Хармонија, заштита, позитивна енергија."
    },
    {
        id: 11,
        title: "Фикус Робуста",
        type: "potted",
        priceMKD: 3630,
        image: "sliki/s8.avif",
        description: "Ficus Robusta е впечатливо и елегантно растение познато по своите големи, дебели и сјајни листови и исправен раст. Потекнува од Југоисточна Азија и е безвременски избор за ентериер кој внесува модерен и скулптурален изглед во секој простор. Симболика: Сила, изобилство, издржливост."
    },
    {
        id: 12,
        title: "Фикус Бонсаи",
        type: "potted",
        priceMKD: 7630,
        image: "sliki/s10.avif",
        description: " Фикус бонсаи (Ficus microcarpa) е елегантно и декоративно собно растение со потекло од тропските предели на Југоисточна Азија. Се издвојува со својот впечатлив, извиткан труп и густо, сјајно зелено лисје, кое му дава уникатен и уметнички изглед. Идеален избор за модерен, минималистички или zen ентериер, каде внесува чувство на мир и природна рамнотежа."
    },
    {
        id: 13,
        title: "Црвени рози со еукалиптус",
        type: "roses",
        priceMKD: 2700,
        image: "sliki/r4.avif",
        description: "Прекрасна комбинација од раскошни 11 црвени рози и свеж еукалиптус, која создава модерен и природен изглед. Контрастот помеѓу интензивните црвени цветови и зеленилото му дава на букетот посебна свежина и елеганција. Совршен избор за романтични прилики и моменти кои сакате да останат запаметени."
    },
    {
        id: 14,
        title: "Red Code",
        type: "roses",
        priceMKD: 3500,
        image: "sliki/r5.avif",
        description: "Уникатен и впечатлив букет составен од 14 црвени рози и една бела роза, која создава прекрасен контраст и му дава посебно значење на аранжманот. Црвените рози ја симболизираат љубовта и страста, додека белата внесува нежност и чистота. Идеален избор за романтична личност и посебни пригоди."
    },
    {
        id: 15,
        title: "Pink Candy",
        type: "roses",
        priceMKD: 1900,
        image: "sliki/r7.avif",
        description: "Разигран и нежен букет во прекрасни розеви нијанси, создаден за оние кои сакаат нешто слатко, весело и посебно. Pink Candy внесува свежина и романтика со својот модерен и шармантен изглед. Идеален избор за родендени, прослави или едноставно за да израдувате некого."
    },
    {
        id: 16,
        title: "Pink Candy & Teddy",
        type: "roses",
        priceMKD: 2200,
        image: "sliki/r6.avif",
        description: "Совршена комбинација од нежен Pink Candy букет и слатко мече, создадена за подарок исполнет со љубов и внимание. Прекрасниот цветен аранжман и симпатичниот детаљ создаваат топол и незаборавен подарок, идеален за сакана личност, роденден, годишнина или посебен повод."
    },
    {
        id: 21,
        title: "Пурпурен Шампањ",
        type: "roses",
        priceMKD: 3500,
        image: "sliki/r12.avif",
        description: "Елегантен и безвременски букет од длабоко црвени и кремасти ружи, симбол на љубов, страст и префинетост. Совршена комбинација за романтични моменти, годишнини и специјални признанија. Напомена: Поради моментална достапност, некои цветови може да варираат, но секогаш ќе бидат заменети со подеднакво убави и соодветни цветови."
    },
    {
        id: 17,
        title: "Cupid's Choice",
        type: "roses",
        priceMKD: 3500,
        image: "sliki/r8.avif",
        description: "Луксузен букет од длабоко црвени и нежни розови рози, елегантно завиткан во стилска хартија. Безвременски израз на љубов, страст и романтика — совршен за Денот на вљубените и значајни моменти што се паметат засекогаш."
    },
    {
        id: 18,
        title: "31 Црвена Роза",
        type: "roses",
        priceMKD: 6500,
        image: "sliki/r9.avif",
        description: "Овој впечатлив букет од 31 црвена роза е безвременски симбол на длабока љубов, страст и искрени емоции. Совршено аранжираните рози создаваат богата и луксузна форма, додека елегантната бела амбалажа и бордо панделка му даваат префинет и свечен изглед. Идеален избор за годишнини, родендени, романтични изненадувања или кога сакате да кажете „Те сакам“ без зборови. "
    },
    {
        id: 19,
        title: "55 Црвени Рози",
        type: "roses",
        priceMKD: 11500,
        image: "sliki/r10.avif",
        description: "Овој впечатлив букет од 55 црвени рози е безвременски симбол на длабока љубов, страст и искрени емоции. Совршено аранжираните рози создаваат богата и луксузна форма, додека елегантната бела амбалажа и бордо панделка му даваат префинет и свечен изглед. Идеален избор за годишнини, родендени, романтични изненадувања или кога сакате да кажете „Те сакам“ без зборови."
    },
    {
        id: 20,
        title: "101 Роза во кутија",
        type: "roses",
        priceMKD: 22000,
        image: "sliki/r11.avif",
        description: "Кога сакате да кажете „те сакам“ на највпечатлив начин. 101 раскошна црвена роза совршено аранжирани во елегантна кутија создаваат подарок што остава без здив. Симбол на страст, љубов и внимание – идеален за моменти што мора да се паметат. Совршен избор за големи емоции и незаборавно изненадување."
    },
    {
        id: 23,
        title: "Pink Dream",
        type: "classic",
        priceMKD: 2800,
        image: "sliki/b1.avif",
        description: "Овој романтичен букет спојува нежни пастелни тонови со богато зеленило за безвременски и елегантен изглед. Содржи меки розови рози, разиграни каранфили, кремасто бели лизиантуси и лаванда хризантеми, убаво надополнети со еукалиптус и сезонско зеленило. Завиткан во чиста бела хартија и завршен со сатенска розова панделка, аранжманот изгледа свежо, воздушесто и природно елегантно."
    },
    {
        id: 24,
        title: "Розево бел микс",
        type: "classic",
        priceMKD: 1500,
        image: "sliki/b2.avif",
        description: "Елегантен и нежен букет кој им е омилен на сите дами. Напомена: Поради моментална и сезонска достапност, некои цветови може да варираат, но секогаш ќе бидат заменети со подеднакво убави и соодветни цветови."
    },
    {
        id: 25,
        title: "Летна приказна",
        type: "classic",
        priceMKD: 2200,
        image: "sliki/b3.avif",
        description: "Весел и шармантен букет исполнет со розеви, виолетови, жолти и бели цветови, кој ги доловува убавината и свежината на летото. Разиграната комбинација на бои создава нежна и весела атмосфера, додека разновидните цветови му даваат природен и уникатен изглед. Совршен избор за родендени, прослави, благодарност или едноставно за да внесете малку сонце и радост во нечиј ден."
    },
    {
        id: 26,
        title: "Baby Blue & White Mix",
        type: "classic",
        priceMKD: 2200,
        image: "sliki/b20.avif",
        description: "Нежен и префинет букет во прекрасна комбинација од светло сини и бели цветови, создаден за моменти исполнети со нежност и елеганција. Светлите нијанси му даваат свеж и модерен изглед, додека хармоничното спојување на боите создава чувство на мир и чистота. Совршен избор за родендени, крштевки, прослави или како нежен знак на внимание за некоја посебна личност."
    },
    {
        id: 27,
        title: "Graduation Bouquet",
        type: "classic",
        priceMKD: 2400,
        image: "sliki/b30.avif",
        description: "Прославете го дипломирањето на најубав начин со овој елегантен цветен букет кој содржи свежо сезонско цвеќе, матурска/дипломска мечка и честитка. Внимателно аранжиран во премиум пастелно пакување, овој букет е совршен подарок за секој матурант или дипломец. Изборот на цвеќе може да варира според сезонската достапност, додека стилот и боите ќе останат внимателно усогласени."
    },
    {
        id: 28,
        title: "Шарен Микс",
        type: "classic",
        priceMKD: 1500,
        image: "sliki/sm.avif",
        description: "Разигран и впечатлив букет исполнет со разновидни цветови во прекрасна комбинација од живописни бои. Различните нијанси создаваат весела и позитивна атмосфера, додека внимателно избраните цветови му даваат природен и уникатен изглед. Совршен избор за родендени, прослави, честитки или едноставно за да внесете боја и радост во нечиј де"
    },
    {
        id: 29,
        title: "Свежо цвеќе во вазна",
        type: "classic",
        priceMKD: 1800,
        image: "sliki/sv.avif",
        description: "Прекрасен аранжман од свежо цвеќе внимателно избрано и уредно поставено во елегантна вазна. Разновидните цветови создаваат природен и освежителен изглед, совршен за внесување боја и убавина во секој простор. Идеален избор за подарок, посебна пригода или едноставно за да го разубавите домот со допир на свежина и елеганција."
    },
    {
        id: 30,
        title: "Црвено-бел микс",
        type: "classic",
        priceMKD: 1500,
        image: "sliki/b10.avif",
        description: "Елегантен и впечатлив букет во класична комбинација од црвени и бели цветови. Контрастот помеѓу интензивните црвени и нежните бели нијанси создава хармоничен и префинет изглед. Совршен избор за љубовни моменти, прослави, годишнини или како прекрасен знак на внимание за некоја посебна личност."
    },
    {
        id: 31,
        title: "Црвен Микс",
        type: "classic",
        priceMKD: 2000,
        image: "sliki/b11.avif",
        description: "Богат и впечатлив букет исполнет со цветови во различни црвени нијанси, создаден да внесе топлина, страст и елеганција. Хармонично комбинираните цветови му даваат раскошен и модерен изглед, совршен за романтични моменти, прослави, годишнини или како посебен знак на внимание."
    }
];

let currentFilters = {
    category: 'all',
    search: '',
    sort: 'default'
};

document.addEventListener("DOMContentLoaded", () => {
    const productGrid = document.getElementById("productGrid");
    if (productGrid) {
        const pageType = productGrid.getAttribute("data-page-type");
        const urlParams = new URLSearchParams(window.location.search);
        const selectedType = urlParams.get("type");

        if (pageType === "featured") {
            renderProducts(productsData.slice(0, 3), productGrid);
        } else {
            if (selectedType) {
                currentFilters.category = selectedType;
                document.querySelectorAll('.filter-btn').forEach(btn => {
                    if (btn.getAttribute('data-filter') === selectedType) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
            }
            filterShopProducts();
        }
    }

    // Слушач за полето за пребарување
    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
        searchInput.addEventListener("input", (e) => {
            filterShopProducts({ search: e.target.value });
        });
    }

    // Слушач за селекторот за сортирање
    const sortSelect = document.getElementById("sortSelect");
    if (sortSelect) {
        sortSelect.addEventListener("change", (e) => {
            filterShopProducts({ sort: e.target.value });
        });
    }

    // Слушачи за копчињата за категории
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener("click", (e) => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            filterShopProducts({ category: e.target.getAttribute('data-filter') });
        });
    });
});

// Глобална функција за филтрирање која ги поддржува категоријата, пребарувањето и сортирањето
window.filterShopProducts = function(newOptions = {}) {
    currentFilters = { ...currentFilters, ...newOptions };

    let filtered = productsData.filter(product => {
        let matchesCategory = true;
        if (currentFilters.category && currentFilters.category !== 'all') {
            matchesCategory = product.type === currentFilters.category;
        }

        let matchesSearch = true;
        if (currentFilters.search) {
            const query = currentFilters.search.toLowerCase();
            matchesSearch = product.title.toLowerCase().includes(query) ||
                product.description.toLowerCase().includes(query);
        }

        return matchesCategory && matchesSearch;
    });

    // Сортирање
    // Сортирање
    if (currentFilters.sort === 'price-asc') {
        filtered.sort((a, b) => a.priceMKD - b.priceMKD);
    } else if (currentFilters.sort === 'price-desc') {
        filtered.sort((a, b) => b.priceMKD - a.priceMKD);
    } else if (currentFilters.sort === 'name-asc') {
        filtered.sort((a, b) => a.title.localeCompare(b.title));
    }

    const productGrid = document.getElementById("productGrid");
    const resultsCount = document.getElementById("resultsCount");

    if (resultsCount) {
        resultsCount.innerText = `Прикажани се ${filtered.length} производи`;
    }

    if (productGrid) {
        renderProducts(filtered, productGrid);
    }
};

function renderProducts(items, container) {
    if (items.length === 0) {
        container.innerHTML = `<p style="grid-column: 1 / -1; text-align: center; color: var(--muted); padding: 40px;">Нема производи во оваа категорија.</p>`;
        return;
    }

    let html = "";
    items.forEach(product => {
        const priceInDenars = product.priceMKD; // Директно ја користиме цената во денари
        html += `
          <article class="product-card">
            <div class="product-image">
              <img src="${product.image}" alt="${product.title}">
            </div>
            <div class="product-body">
              <h3 style="font-size: 18px; margin-bottom: 6px;">${product.title}</h3>
              <p style="color: var(--muted); font-size: 14px; margin-bottom: 15px; flex-grow: 1;">${product.description}</p>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-top: auto;">
                <strong style="font-size: 18px; color: var(--primary);">${priceInDenars.toLocaleString()} ден.</strong>
                <button onclick="addToCart(${product.id}, '${product.title.replace(/'/g, "\\'")}', ${priceInDenars}, '${product.image}')" class="btn btn-dark" style="padding: 8px 16px; font-size: 14px;">Додај во корпа</button>
              </div>
            </div>
          </article>
        `;
    });
    container.innerHTML = html;
}