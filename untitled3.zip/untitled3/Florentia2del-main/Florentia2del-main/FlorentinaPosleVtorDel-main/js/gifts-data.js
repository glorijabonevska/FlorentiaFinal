const giftsData = [
    {
        id: 201,
        title: "Луксузен парфем „Blooming flower“",   //naslovce
        category: "perfumes",  //ova e bitno za filterot dali spagja vo mecinja, parfemi i slicno
        priceMKD: 1850,     //random cena stavete si
        image: "sliki/p1.jpg", //pateka od folderot sliki/imageBROJ_NA_SLIKA
        badge: "Новитет",  //sto da pisuva vo bravoagolniceto gore levo
        badgeColor: "",   //voja na pravoagolniceto eventualno
        description: "Префинети цветни ноти од јасмин, роза и бел мускус спакувани во елегантно шише за незаборавни моменти."   //tekstot vo opis
    },
    {
        id: 202,
        title: "Мече со розево плиш срце",
        category: "plush",
        priceMKD: 750,
        image: "sliki/mec.jpg",
        badge: "Популарно",
        badgeColor: "#d4af37",
        description: "Мек, нежен и совршен придружник за изненадување за роденден, годишнина или Денот на вљубените."
    },
    {
        id: 203,
        title: "Златна керамичка вазна за букети",
        category: "decor",
        priceMKD: 920,
        image: "sliki/v.jpg",
        badge: "",
        badgeColor: "",
        description: "Прекрасна дизајнерска вазна со фина текстура која секој свеж букет го прави да изгледа уште побогато и поелегантно."
    },
    {
        id: 204,
        title: "Мал затворен терариум со фитонија",
        category: "florist",
        priceMKD: 1540,
        image: "https://i.etsystatic.com/23597110/r/il/85938b/7319297928/il_794xN.7319297928_chlo.jpg",
        badge: "Еко флора",
        badgeColor: "#2e7d32",
        description: "Мал затворен стаклен терариум со жива фитонија и природен мов, уреден како минијатурен зелен екосистем."
    },
    {
        id: 205,
        title: "Правоаголен стаклен терариум со мов",
        category: "florist",
        priceMKD: 2100,
        image: "https://i.etsystatic.com/50207840/r/il/fb95a1/7126781170/il_794xN.7126781170_2a7z.jpg",
        badge: "Bestseller",
        badgeColor: "#2e7d32",
        description: "Елегантен правоаголен стаклен терариум со природен зелен мов и минијатурен пејзаж, идеален за украсување на домот."
    },
    {
        id: 206,
        title: "Геометриски терариум со мов и сукуленти",
        category: "florist",
        priceMKD: 2850,
        image: "https://i.etsystatic.com/55604334/r/il/cd9a2e/6604688138/il_794xN.6604688138_13v5.jpg",
        badge: "Уникатно",
        badgeColor: "#2e7d32",
        description: "Декоративен геометриски стаклен терариум со природен мов и минијатурни сукуленти, уреден во модерен стаклен сад."
    },
    {
        id: 207,
        title: "Мини терариум со фитонија и плута",
        category: "florist",
        priceMKD: 3200,
        image: "https://i.etsystatic.com/61479586/r/il/467f1a/7662130791/il_794xN.7662130791_ifsi.jpg",
        badge: "Луксуз",
        badgeColor: "#2e7d32",
        description: "Мал затворен стаклен терариум со плутена капа, жива фитонија, природен мов, камчиња и слоевит природен супстрат."
    },
    {
        id: 209,
        title: "Големо бело плишено мече",
        category: "plush",
        priceMKD: 1400,
        image: "sliki/m2.jpg",
        badge: "Популарно",
        badgeColor: "#d4af37",
        description: "Големо и меко бело плишено мече, совршено за подарок на сакана личност и посебни пригоди."
    },
    {
        id: 210,
        title: "Мече со црвено срце",
        category: "plush",
        priceMKD: 950,
        image: "sliki/m1.jpg",
        badge: "Новитет",
        badgeColor: "#d4af37",
        description: "Нежно плишено мече со црвено срце, идеално за романтични подароци и изненадувања."
    },
    {
        id: 211,
        title: "Мало кафено плишено мече",
        category: "plush",
        priceMKD: 650,
        image: "sliki/m3.jpg",
        badge: "",
        badgeColor: "",
        description: "Мало и преслатко плишено мече кое одлично се комбинира со букет цвеќе или друг подарок."
    },
    {
        id: 212,
        title: "Розево мече",
        category: "plush",
        priceMKD: 1500,
        image: "./sliki/m4.jpg",
        badge: "Популарно",
        badgeColor: "#d4af37",
        description: "Слатко розево плишено мече, создадено за романтични моменти и посебни личности."
    },
    {
        id: 213,
        title: "Плишено мече со цвет",
        category: "plush",
        priceMKD: 1100,
        image: "sliki/m5.jpg",
        badge: "",
        badgeColor: "",
        description: "Меко плишено мече со прекрасен цветен детал, идеално како дополнување на подарок."
    },
    {
        id: 214,
        title: "Слатко кремасто мече",
        category: "plush",
        priceMKD: 750,
        image: "sliki/m6.jpg",
        badge: "",
        badgeColor: "",
        description: "Нежно кремасто плишено мече со симпатичен изглед, погодно за различни прилики."
    },
    {
        id: 215,
        title: "Florence",
        category: "perfumes",
        priceMKD: 2200,
        image: "sliki/f2.jpg",
        badge: "Ексклузивно",
        badgeColor: "#d4af37",
        description: "Софистициран парфем со луксузен и модерен мирис, идеален за посебни прилики."
    },
    {
        id: 216,
        title: "Floratta Love",
        category: "perfumes",
        priceMKD: 2050,
        image: "sliki/p4.jpg",
        badge: "Романтичен",
        badgeColor: "#d4af37",
        description: "Романтичен цветен мирис со нежни ноти, создаден како совршен подарок за сакана личност."
    },
    {
        id: 217,
        title: "Florentia Secret",
        category: "perfumes",
        priceMKD: 1950,
        image: "sliki/p2.jpg",
        badge: "",
        badgeColor: "",
        description: "Модерен и пријатен парфем со нежен карактер, погоден за секојдневно носење."
    },
    {
        id: 218,
        title: "Florentia Yellow",
        category: "perfumes",
        priceMKD: 2300,
        image: "sliki/p3.jpg",
        badge: "Луксуз",
        badgeColor: "#d4af37",
        description: "Топол и елегантен мирис со богати ноти, создаден за оние кои сакаат пософистициран парфем."
    },
    {
        id: 221,
        title: "Елегантна бела вазна",
        category: "decor",
        priceMKD: 900,
        image: "sliki/v1.jpg",
        badge: "Новитет",
        badgeColor: "#d4af37",
        description: "Минималистичка бела вазна која прекрасно се вклопува со свежи букети и модерен ентериер."
    },
    {
        id: 222,
        title: "Златна декоративна вазна",
        category: "decor",
        priceMKD: 1250,
        image: "sliki/v2.jpg",
        badge: "Луксуз",
        badgeColor: "#d4af37",
        description: "Елегантна декоративна вазна со златни детали која внесува луксузен изглед во секој простор."
    },
    {
        id: 223,
        title: "Стаклена вазна за цвеќе",
        category: "decor",
        priceMKD: 850,
        image: "sliki/v3.jpg",
        badge: "",
        badgeColor: "",
        description: "Едноставна и елегантна стаклена вазна погодна за свежи цвеќиња и различни цветни аранжмани."
    },
    {
        id: 224,
        title: "Мала декоративна вазна",
        category: "decor",
        priceMKD: 650,
        image: "sliki/v4.jpg",
        badge: "",
        badgeColor: "",
        description: "Мала декоративна вазна идеална за маса, полица или работен простор."
    },
    {
        id: 225,
        title: "Модерна керамичка вазна",
        category: "decor",
        priceMKD: 1100,
        image: "sliki/v5.jpg",
        badge: "Популарно",
        badgeColor: "#d4af37",
        description: "Модерна керамичка вазна со уникатен дизајн која додава стил и елеганција во домот."
    },
    {
        id: 226,
        title: "Голема вазна за букети",
        category: "decor",
        priceMKD: 1350,
        image: "sliki/v6.jpg",
        badge: "",
        badgeColor: "",
        description: "Поголема декоративна вазна наменета за богати букети и впечатливи цветни аранжмани."
    },
    {
        id: 227,
        title: "Луксузна вазна",
        category: "decor",
        priceMKD: 1600,
        image: "sliki/v7.jpg",
        badge: "Ексклузивно",
        badgeColor: "#d4af37",
        description: "Луксузна вазна со впечатлив дизајн, создадена како посебен декоративен детал за домот."
    },
    {
        id: 228,
        title: "Декоративен украс за дом",
        category: "decor",
        priceMKD: 700,
        image: "sliki/d1.jpg",
        badge: "",
        badgeColor: "",
        description: "Елегантен декоративен украс кој внесува топлина, стил и пријатна атмосфера во домот."
    },
    {
        id: 229,
        title: "Мал украсен сад",
        category: "decor",
        priceMKD: 500,
        image: "sliki/d2.jpg",
        badge: "",
        badgeColor: "",
        description: "Декоративен сад со модерен изглед, погоден за различни простории и стилови на ентериер."
    },
    {
        id: 230,
        title: "Декоративен сет за дом",
        category: "decor",
        priceMKD: 900,
        image: "sliki/d4.jpg",
        badge: "Новитет",
        badgeColor: "#d4af37",
        description: "Елегантен декоративен сет кој може да биде прекрасен подарок за секој дом."
    },
    {
        id: 231,
        title: "Декоративен свеќник",
        category: "decor",
        priceMKD: 750,
        image: "sliki/d3.jpg",
        badge: "",
        badgeColor: "",
        description: "Елегантен декоративен свеќник кој создава топла и пријатна атмосфера во секој дом."
    },
    {
        id: 232,
        title: "Декоративна кутија за накит",
        category: "decor",
        priceMKD: 1200,
        image: "sliki/d5.jpg",
        badge: "Популарно",
        badgeColor: "#d4af37",
        description: "Стилска декоративна кутија за накит и мали лични предмети, идеална како подарок."
    },
    {
        id: 233,
        title: "Декоративна рамка за фотографии",
        category: "decor",
        priceMKD: 850,
        image: "sliki/d6.jpg",
        badge: "",
        badgeColor: "",
        description: "Елегантна рамка за фотографии која ги претвора омилените спомени во прекрасен украс за домот."
    }
];