const translations = {
    mk: {
        home: "Почетна",
        aboutTeam: "За нас & Тим",
        products: "Производи",
        potted: "Саксиски цвеќиња",
        gifts: "Подароци",
        weddings: "Свадбени букети",
        classic: "Класични букети",
        roses: "Рози",
        faq: "FAQ",
        contact: "Контакт",
        cart: "Корпа",
        explore: "Истражи ја колекцијата",
        featured: "Наши омилени"
    },
    en: {
        home: "Home",
        aboutTeam: "About & Team",
        products: "Products",
        potted: "Potted Plants",
        gifts: "Gifts",
        weddings: "Wedding Bouquets",
        classic: "Classic Bouquets",
        roses: "Roses",
        faq: "FAQ",
        contact: "Contact",
        cart: "Cart",
        explore: "Explore Collection",
        featured: "Featured Favorites"
    }
};